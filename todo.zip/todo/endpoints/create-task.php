<?php
header( "Access-Control-Allow-Origin: *" );
header( "Access-Control-Allow-Methods: POST" );
header( "Content-type: application/json; charset=UTF-8" );
//create task
include_once( "../Todo.class.php" );

if( !empty( $_POST["task_name"] ) )
{
 
   $task = htmlspecialchars( strip_tags( $_POST['task_name'] ) );;
   $status = 'new';
   $created_at = date( "d-m-y H:i:s" );
   $due_date = $_POST["due_date"];
   $task_id = rand( 100000, 999999 );
  

 
 $result = $todo->create_task( $task_id, $task, $status, $created_at, $due_date );


 if( $result )
 { 
  $created_at_pn = date( "y M d", strtotime( $created_at ) );
  $due_date_pn = date( "d M y", strtotime( $due_date) );

  echo json_encode( array( "task_name_res" => $_POST['task_name'], "task_id" => $task_id, "created_at" => $created_at_pn, "due_date" => $due_date_pn ) );  
 }
}


?>
