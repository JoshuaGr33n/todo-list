<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-type: application/json; charset=UTF-8");
//create task
include_once( "../Todo.class.php" );

if(!empty($_POST["task_id"]))
{
 
   $task_id = $_POST["task_id"];
   $status = $_POST["status"];
   

 
 $result = $todo->update_task($status,$task_id);


 if($result)
 {
  

  
 }
}


?>
