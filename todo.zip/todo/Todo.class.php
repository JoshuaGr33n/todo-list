<?php
include_once ('include/db.php');


class Todo
{
    public $conn;
    private $wp_todo;
   

    //constructor
    public function __construct(){
        $db = new Database();
        $this->conn = $db->connect();
        global $wpdb;
    }



    public function get_all_tasks(){
        global $wpdb;
        $role_query = "SELECT * FROM {$wpdb->prefix}todo ORDER BY due_date ASC";
        $role_obj = $this->conn->prepare($role_query);
        if ($role_obj->execute()) {
            return $role_obj->get_result();
        }
        return array();
    }
    public function create_task($task_id, $task, $status, $created_at, $due_date){
        
        $temp_query = "INSERT INTO wp_todo SET 
                    task_id=?,
                    task=?,status=?,
                   created_at=?,due_date=?";
        $temp_obj = $this->conn->prepare($temp_query);
        $temp_obj->bind_param("sssss",$task_id, $task, $status, $created_at, $due_date);
        if ($temp_obj->execute()) {
            return true;
        }
        return false;
    }


    public function update_task($status,$task_id){
        
        $update_task_query = "UPDATE wp_todo SET status='$status' WHERE task_id =$task_id";
        $update_task_obj = $this->conn->prepare($update_task_query);
        if ($update_task_obj->execute()){
            return true;
        }
        return false;
    }
    public function delete_task( $task_id ){
        
        $delete_task_query = "DELETE FROM wp_todo WHERE task_id =$task_id";
        $delete_task_obj = $this->conn->prepare($delete_task_query);
        if ($delete_task_obj->execute()){
            if ($delete_task_obj->affected_rows > 0){ return true; }
            return false;
        }
        return false;
           
    }

    



}

$todo = new Todo();
?>