   
   <?php 
     include_once( "Todo.class.php" );
      $c = 0; 
      $res = $todo->get_all_tasks();
    ?> 
   <h1>Todo</h1>
   
   <span style="margin-left:60px">All(<?=$res->num_rows;?>)</span>
   
   <table class="widefat fixed" cellspacing="0" style="width:90%;margin:auto;margin-top:20px">
     <thead>
     <tr>
 
             <th id="cb" class="manage-column column-cb check-column" scope="col"></th> 
             <th id="columnname" class="manage-column column-columnname" scope="col">Title</th>
             <th id="columnname" class="manage-column column-columnname" scope="col">Status</th>
             <th id="columnname" class="manage-column column-columnname " scope="col">Created At</th> 
             <th id="columnname" class="manage-column column-columnname " scope="col">Due Date</th> 
 
     </tr>
     </thead>
 
     <tfoot>
     <tr>
 
             <th class="manage-column column-cb check-column" scope="col"></th>
             <th id="columnname" class="manage-column column-columnname" scope="col">Title</th>
             <th id="columnname" class="manage-column column-columnname" scope="col">Status</th>
             <th id="columnname" class="manage-column column-columnname " scope="col">Created At</th> 
             <th id="columnname" class="manage-column column-columnname " scope="col">Due Date</th> 
 
     </tr>
     </tfoot>
 
     <tbody>
        
         <?php       
         if ( $res->num_rows > 0 ) { $n=0;
            while ( $row = $res->fetch_assoc() ) {
                $created_at = date("y M d", strtotime($row["created_at"]));
                $due_date = date("d M y", strtotime($row["due_date"]));
                if( $row["status"] == 'done' ) {
                   $status_color = 'rgb(52,140,49)';
                }
                if( $row["status"] == 'cancelled' ) {
                    $status_color = 'rgb(255, 0, 0)';
                }
                if( $row["status"] == 'new' ) {
                    $status_color = '#87CEEB';
                }
        ?>
         <tr class="<?=($c++%2==1) ? 'alternate' : '' ?>">
             <th class="check-column" scope="row"></th>
             <td class="column-columnname"><?=ucfirst($row["task"]);?></td>
             <td class="column-columnname" style="color:<?=$status_color;?>"><?=ucfirst($row["status"]);?></td>
             <td class="column-columnname"><?=$created_at;?></td>
             <td class="column-columnname"><?=$due_date;?></td>
         </tr>
         <?php }}?>
         
     </tbody>
 </table>