1. Download the plugin in compressed format. 

2. Log into your WordPress admin site and go to the     Plugins section.

3. Click on Add New > Upload Plugin and select the      zip file. 

4. Activate the plugin.

5. Go back to your WordPress admin menu, scroll         down, and look for the plugin settings. Make sure    the plugin is activated.

6. Referesh the frontend.