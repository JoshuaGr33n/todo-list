<?php
 
/*
 
Plugin Name: Todo
 
Plugin URI: http://localhost/decagon_test/
 
Description: Todo List.
 
Version: 1.0
 
Author: Joshua Oleru
 
Author URI: http://localhost/decagon_test/
 
License: GPLv2 or later
 
Text Domain: Decagon
 
*/

function td_login_logo() { ?>
      <style type="text/css">
          #login h1 a, .login h1 a {
              background-image: url(https://img.freepik.com/free-icon/todo-list_318-10185.jpg?w=740);
          height:200px;
          width:300px;
          background-size: 300px 200px;
          background-repeat: no-repeat;
          padding-bottom: 10px;
          }
      </style>
<?php 
}
  add_action( 'login_enqueue_scripts', 'td_login_logo' );



function td_login_logo_url() {
   return home_url();
}
add_filter( 'login_headerurl', 'td_login_logo_url' );


function td_login_logo_url_title() {
    return 'ToDO';
}
add_filter( 'login_headertitle', 'td_login_logo_url_title' );


function td_todo_content()
{           
include( $dir."plugin.php" );          
}
add_action( 'the_content', 'td_todo_content' );



function td_add_the_admin_page(){
      add_menu_page( 'Todo List', 'Todo', 'manage_options', 'theme-options', 'td_page_content', 'dashicons-editor-ul' );
}
  add_action('admin_menu', 'td_add_the_admin_page');

function td_page_content(){
      include( $dir."admin-todo.php" );
}